package practice;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.TreeSet;
import java.util.Vector;
public class Project5 {
	public static void main(String[] args)
	{
		arraylist();
		linkedlist();
		vectorlist();
		hashset();
		treeset();
	}
	public static void treeset()
	{
		TreeSet<Character> t=new TreeSet<Character>();
		t.add('d');
		t.add('D');
		t.add('e');
		t.add('v');
		t.add('h');
		t.add('s');
		//t.add(null);
		System.out.println("-------------------------------------------");
		Iterator itr=t.iterator();
		System.out.println("Hashset: ");
		while(itr.hasNext())
		{
			System.out.println(itr.next()+" ");
		}
		System.out.println("-------------------------------------------");
		System.out.println("Length of Hashset : "+t.size());
		System.out.println("-------------------------------------------");
	}
	public static void hashset()
	{
		HashSet<Integer> h=new HashSet<Integer>();
		h.add(52);
		h.add(89);
		h.add(45);
		h.add(22);
		h.add(null);
		h.add(0);
		h.add(22);
		System.out.println("-------------------------------------------");
		Iterator itr=h.iterator();
		System.out.println("Hashset: ");
		while(itr.hasNext())
		{
			System.out.println(itr.next()+" ");
		}
		System.out.println("-------------------------------------------");
		System.out.println("Length of Hashset : "+h.size());
		System.out.println("-------------------------------------------");
		
	}
	public static void arraylist()
	{
		ArrayList<Double> a=new ArrayList<Double>();
		a.add(54.0);
		a.add(89.89);
		a.add(98.02);
		a.add(41.63);
		a.add(50.015);
		System.out.println("-------------------------------------------");
		Iterator itr=a.iterator();
		System.out.println("ArrayList: ");
		while(itr.hasNext())
		{
			System.out.println(itr.next()+" ");
		}
		System.out.println("Length of Arraylist : "+a.size());
		System.out.println("-------------------------------------------");
		System.out.println("Arraylist after removing 1st index: ");
		a.remove(1);
		for(double i:a)
		{
			System.out.println(i);
		}
		System.out.println("Length of my Arraylist : "+a.size());
		System.out.println("-------------------------------------------");
		a.clear();
		System.out.println("Is my Arraylist is Empty: "+a.isEmpty());
		System.out.println("-------------------------------------------");
		
	}
	public static void linkedlist()
	{
		LinkedList<Integer> l=new LinkedList<Integer>();
		l.add(8);
		l.add(66);
		l.add(45);
		l.add(520);
		l.add(98);
		l.addFirst(7);
		l.addLast(89);
		Iterator itr=l.iterator();
		System.out.println("LinkedList: ");
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		System.out.println("-------------------------------------------");
		System.out.println("Length of my LinkedListlist : "+l.size());
		System.out.println("-------------------------------------------");
		System.out.println("Element present in "+Collections.binarySearch(l, 45)+" index");
		System.out.println("-------------------------------------------");
		Collections.sort(l);
		System.out.println("Sorted LinkedListlist : "+l);
		System.out.println("-------------------------------------------");
	}
	public static void vectorlist()
	{
		Vector<String> v=new Vector<String>();
		v.add("Saha");
		v.add("Dhanu");
		v.add("vuha");
		Iterator itr=v.iterator();
		System.out.println("VectorList: ");
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		System.out.println("-------------------------------------------");
		System.out.println("Is vuha present in this vectorlist: "+v.contains("vuha"));
		System.out.println("-------------------------------------------");
		Collections.sort(v);
		System.out.println(v);
		System.out.println("-------------------------------------------");
		System.out.println("Length of vectorlist: "+v.size());
		System.out.println("-------------------------------------------");
	}

}
