package practice;
import java.util.regex.*;
import java.util.Scanner;
public class Project10 {
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a String of your wish: ");
		String str=sc.nextLine();
		System.out.println("Enter a String that is a pattern: ");
		String s=sc.nextLine();
		Pattern pattern = Pattern.compile(s);
		Matcher m = pattern.matcher(str);
		while (m.find())
		{
			System.out.println("Pattern found from "+ m.start() + " to "+ (m.end() - 1));
		}
	}

}

