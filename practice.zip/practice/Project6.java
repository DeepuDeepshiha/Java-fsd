package practice;

import java.util.HashMap;
import java.util.TreeMap;

public class Project6 {
	public static void main(String[] args)
	{
		hashmap();
		treemap();
	}
	public static void treemap()
	{
		TreeMap<String,Long> t=new TreeMap<String,Long>();
		scooty s1=new scooty("suzuki access 125",90000);
		scooty s2=new scooty("honda active 6G",76000);
		scooty s3=new scooty("TVS Jupiter 125",80000);
		t.put(s1.name,s1.price);
		t.put(s2.name, s2.price);
		t.put(s3.name, s3.price);
		System.out.println("-------------------------");
		System.out.println("TreeMap Keysets: ");
		for(String i:t.keySet())
		{
			System.out.println(i);
		}
		System.out.println("-------------------------");
		System.out.println("TreeMap Values: ");
		for(long s:t.values())
		{
			System.out.println(s);
		}
		System.out.println("-------------------------");
		System.out.println("Length of TreeMap: "+t.size());
		System.out.println("-------------------------");
		System.out.println("TreeMap as string : "+t.toString());
		System.out.println("-------------------------");
		t.replace("honda active 6G",(long)76000,(long)100000);
		System.out.println("TreeMap as string : "+t.toString());
		System.out.println("-------------------------");
	}
	public static void hashmap()
	{
		HashMap<Integer,String> h=new HashMap<Integer,String>();
		car c1=new car("Benz",5000000.00);
		car c2=new car("TATA nano",250000.00);
		car c3=new car("BMW",50000000);
		h.put(1, c1.name);
		h.put(2, c2.name);
		h.put(3, c3.name);
		//h.put(null, null);
		h.put(4, c2.name);
		System.out.println("-------------------------");
		System.out.println("HashMap Keysets: ");
		for(int i:h.keySet())
		{
			System.out.println(i);
		}
		System.out.println("-------------------------");
		System.out.println("HashMap Values: ");
		for(String s:h.values())
		{
			System.out.println(s);
		}
		System.out.println("-------------------------");
		System.out.println("Length of HashMap: "+h.size());
		System.out.println("-------------------------");
		System.out.println("HashMap as string : "+h.toString());
		h.replace(4, "TATA nano", null);
		System.out.println("-------------------------");
		System.out.println("HashMap as string : "+h.toString());
		System.out.println("-------------------------");
	}

}

class car
{
	String name;
	double price;
	public car(String name,double price)
	{
		this.name=name;
		this.price=price;
	}
}

class scooty
{
	String name;
	long price;
	public scooty(String name,long price)
	{
		this.name=name;
		this.price=price;
	}
}