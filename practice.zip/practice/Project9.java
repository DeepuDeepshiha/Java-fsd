package practice;
import java.util.Scanner;
public class Project9 {
	public static void main(String [] args)
	{
		singledimensionarray();
		multidimensionarray();
	}
	public static void multidimensionarray()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter how many rows you want: ");
		int r=sc.nextInt();
		System.out.println("Enter how many columns you want: ");
		int c=sc.nextInt();
		int arr[][]=new int[r][c];
		System.out.println("Enter the elements: ");
		for(int i=0;i<r;i++)
		{
			for(int j=0;j<c;j++)
			{
				arr[i][j]=sc.nextInt();
			}
		}
		System.out.println("----------------------");
		System.out.println("Elements are ");
		for(int i=0;i<r;i++)
		{
			for(int j=0;j<c;j++)
			{
				System.out.print(arr[i][j]+" ");
			}
			System.out.println();
		}
		System.out.println("----------------------");
		sc.close();
	}
	public static void singledimensionarray()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter how many colors you want to enter: ");
		int n=sc.nextInt();
		String col[]=new String[n];
		System.out.println("Enter the colors: ");
		for(int i=0;i<n;i++)
		{
			col[i]=sc.next();
		}
		System.out.println("----------------------");
		System.out.println("Colors are ");
		for(String s:col)
		{
			System.out.println(s+" ");
		}
		System.out.println("----------------------");
		System.out.println("Enter a random number between 0 and "+n+" for random access the array");
		int m=sc.nextInt();
		if(m>=0 && m<=n)
		{
			System.out.println("Accessed string is "+col[m]);
			System.out.println("----------------------");
		}
		else
		{
			System.out.println("wrong input");
			System.out.println("----------------------");
		}
		sc.close();
	}

}
