package Assistedpractice;
import java.sql.*;
public class Project3 
{
	public static void main(String[] args)
	{
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Student","root","****");
			Statement stm=con.createStatement();
			ResultSet rs=stm.executeQuery("SELECT * FROM Student");
			while(rs.next())
			{
				String name=rs.getString("Stdname");
				String course=rs.getString("Course");
				float fees=rs.getFloat("Fees");
				int roll=rs.getInt("Rollno"); 
				System.out.println(roll+" "+name+" "+course+" "+fees);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
