package Assistedpractice;
import java.sql.*;
public class Project2 
{
	public static void main(String[] args)
	{
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Student","root","****");
            Statement stmt = con.createStatement();
            String sql;
            sql = "SELECT Stdname,Rollno FROM Student";
            ResultSet rs = stmt.executeQuery(sql);
            while(rs.next())
            {
            	String name=rs.getString("Stdname");
            	int roll=rs.getInt("Rollno");
            	System.out.println("Roll no: "+roll+" "+"Name: "+name+" ");
            }
            rs.close();
            stmt.close();
            con.close();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
