package practice;
import java.util.Scanner;
public class Project8 {
	public static void main(String[] args)
	{
		stringbuilder();
		stringbuffer();
	}
	public static void stringbuilder()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number of animal you want: ");
		int n=sc.nextInt();
		System.out.println("----------------------------------------");
		StringBuilder sb=new StringBuilder();
		System.out.println("Enter the Animals: ");
		for(int i=0;i<n;i++)
		{
			sb.append(" "+sc.next());
		}
		System.out.println("----------------------------------------");
		System.out.println("Conversion of String to StringBuilder: "+sb.toString());
		System.out.println("----------------------------------------");
		System.out.println("Is my StringBuilder is Empty: "+sb.isEmpty());
		System.out.println("----------------------------------------");
		sb.replace(1, 2, "Dog");
		System.out.println("Reversing the StringBuilder: "+sb.reverse());
		System.out.println("----------------------------------------");
		sc.close();
		
	}
	public static void stringbuffer()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number of birds you want: ");
		int n=sc.nextInt();
		System.out.println("----------------------------------------");
		StringBuffer sb=new StringBuffer();
		System.out.println("Enter the Birds: ");
		for(int i=0;i<n;i++)
		{
			sb.append(" "+sc.next());
		}
		System.out.println("----------------------------------------");
		System.out.println("Conversion of String to StringBuffer: "+sb.toString());
		System.out.println("----------------------------------------");
		System.out.println("Is my StringBuffer is Empty: "+sb.isEmpty());
		System.out.println("----------------------------------------");
		System.out.println("Substring: "+sb.substring(5, 7));
		System.out.println("----------------------------------------");
		System.out.println("Before applying trim to size: "+sb.capacity());
		sb.trimToSize();
		System.out.println("After applying trim to size: "+sb.capacity());
		System.out.println("----------------------------------------");
		System.out.println("Reversing the StringBuffer: "+sb.reverse());
		System.out.println("----------------------------------------");
		sc.close();
	}
}
