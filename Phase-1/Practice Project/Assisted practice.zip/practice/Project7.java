package practice;
import java.util.Scanner;
public class Project7 {
	public static void main(String[] args)
	{
		System.out.println("Enter 2 numbers: ");
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		outerclass o=new outerclass(a,b);
		sc.close();
	}
	

}

class outerclass
{
	int a,b;
	public outerclass(int a,int b)
	{
		this.a=a;
		this.b=b;
		System.out.println("Outer class constructor");
		class innerclass
		{
			public innerclass(int a,int b)
			{
				System.out.println("Inner class constructor");
				System.out.println("Addition from inner constructor :"+" a="+a+" b="+b+" result="+(a+b));
			}
		}
		innerclass i=new innerclass(a,b);
	}
	
}