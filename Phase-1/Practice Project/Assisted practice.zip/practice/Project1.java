package practice;
import java.util.Scanner;
public class Project1 {
	public static void main(String[] args)
	{
		System.out.println("Enter a character:");
		Scanner sc=new Scanner(System.in);
		char c=sc.next().charAt(0);
		System.out.println("-------------------------");
		implicit(c);
		System.out.println("Enter a integer:");
		int i=sc.nextInt();
		System.out.println("-------------------------");
		explicit(i);
		sc.close();
	}
	public static void implicit(char c)
	{
		System.out.println("Implicit Casting");
		System.out.println("Value of c as Character: "+c);
		int b=c;
		System.out.println("Value of c as Integer: "+b);
		double k=c;
		System.out.println("Value of c as Double: "+k);
		float l=c;
		System.out.println("Value of c as Float: "+l);
		long p=c;
		System.out.println("Value of c as Long: "+p);
		System.out.println("-------------------------");
	}
	public static void explicit(int c)
	{
		System.out.println("Explicit Casting");
		System.out.println("Value of c as Integer: "+c);
		char b=(char)c;
		System.out.println("Value of c as Integer: "+b);
		double k=(double)c;
		System.out.println("Value of c as Double: "+k);
		float l=(float)c;
		System.out.println("Value of c as Float: "+l);
		long p=(long)c;
		System.out.println("Value of c as Long: "+p);
	}
}
