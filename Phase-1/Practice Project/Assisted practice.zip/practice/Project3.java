package practice;

import java.util.Scanner;

public class Project3 {
	public static void main(String[] args)
	{
		System.out.println("Enter 2 numbers:");
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		System.out.println("Enter a employee name and id:");
		String name=sc.next();
		int id=sc.nextInt();
		System.out.println("---------------------------------------------");
		System.out.println("Method without arguments: ");
		display();
		System.out.println("---------------------------------------------");
		System.out.println("Method with arguments: ");
		System.out.println("Arguments are "+a+","+b+" Result is "+add(a,b));
		System.out.println("----------------------------------------------");
		System.out.println("Method as Getter and Setters for an Object: ");
		employee emp=new employee();
		emp.setName(name);
		emp.setEmpid(id);
		System.out.println(emp.getName()+"'s"+" Employee id is "+emp.getEmpid());
		System.out.println("------------------------------------------------");
		System.out.println("Method in Abstract class: ");
		extclass e=new extclass();
		e.show();
		sc.close();
	}
	static void display()
	{
		System.out.println("This is a static method");
	}
	public static int add(int a,int b)
	{
		int r=a+b;
		return r;
	}
	
}
class employee
{
	private String name;
	private int empid;
	public String getName() 
	{
		return name;
	}
	public void setName(String name) 
	{
		this.name = name;
	}
	public int getEmpid() 
	{
		return empid;
	}
	public void setEmpid(int empid)
	{
		this.empid = empid;
	}
	
}


abstract class absclass
{
	public abstract void show();
}
class extclass extends absclass
{
	public void show()
	{
		System.out.println("This is a Abstract method");
	}
}
