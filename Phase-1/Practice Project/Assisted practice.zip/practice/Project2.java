package practice;
import java.util.Scanner;
public class Project2 
{
	public static void main(String[] args)
	{
		System.out.println("Enter an Animal name and Animal's work:");
		Scanner sc=new Scanner(System.in);
		String name=sc.next();
		String work=sc.next();
		System.out.println("------------------------------------------");
		System.out.println("Example for Public access modifiers");
		publicmethod();
		System.out.println("------------------------------------------");
		System.out.println("Example for Private access modifiers");
		animal a=new animal();
		a.setName(name);
		System.out.println("Animal name is "+a.getName()+" Here, Animal's name is a private datatype");
		String str1=a.setWork(work);
		System.out.println("------------------------------------------");
		System.out.println("Example for Protected access modifiers");
		rabbit r=new rabbit();
		r.work(str1,a.getName());
		sc.close();
		
	}
	public static void publicmethod()
	{
		System.out.println("This is a public method");
	}

}

class animal
{
	private String name;
	protected String work;
	public String getName() 
	{
		return name;
	}

	public void setName(String name) 
	{
		this.name = name;
	}
	
	public String setWork(String work) 
	{
		this.work = work;
		return work;
	}
}

class rabbit extends animal
{
	public void work(String str1,String str2)
	{
		System.out.println(str2+" is "+str1+" Here, Animal's work is Protected datatype");
	}
}
