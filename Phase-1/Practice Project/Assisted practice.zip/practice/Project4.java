package practice;
import java.util.Scanner;
public class Project4 {
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Student name:");
		String name=sc.next();
		System.out.println("Enter Student rollno:");
		int rollno=sc.nextInt();
		System.out.println("------------------------");
		System.out.println("Default Constructor");
		Student s1=new Student();
		System.out.println("------------------------");
		System.out.println("Parametrised Constructor");
		Student s2=new Student(name,rollno);
		System.out.println("------------------------");
		System.out.println("Enter Student name, rollno and 5 Subject marks:");
		String str=sc.next();
		int i=sc.nextInt();
		int m1=sc.nextInt();
		int m2=sc.nextInt();
		int m3=sc.nextInt();
		int m4=sc.nextInt();
		int m5=sc.nextInt();
		System.out.println("------------------------");
		Student s3=new Student(str,i,m1,m2,m3,m4,m5);
		sc.close();
	}

}
class Student
{
	String name;
	int rollno,m1,m2,m3,m4,m5;
	public Student()
	{
		System.out.println("This is a Default Constructor");
	}
	public Student(String name,int rollno)
	{
		this.name=name;
		this.rollno=rollno;
		System.out.println("This is a Parametrised Constructor with name and rollno as parameters");
		System.out.println(name+": "+rollno);
	}
	public Student(String name,int rollno,int m1,int m2, int m3, int m4, int m5)
	{
		this.name=name;
		this.rollno=rollno;
		this.m1=m1;
		this.m2=m2;
		this.m3=m3;
		this.m4=m4;
		this.m5=m5;
		int tot=m1+m2+m3+m4+m5;
		System.out.println("This is a Parametrised Constructor with name,rollno and marks as parameters");
		System.out.println("Name:"+name+"  "+"Rollno: "+rollno+" Total: "+tot);
		System.out.println("Avg: "+(tot/5));
	}
}