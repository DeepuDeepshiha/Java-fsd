package assisted.practice2;
import java.util.Scanner;
public class Project6 {
	public static void main(String[] args)
	{
		try
		{
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter how many numbers you want to enter in array: ");
			int n=sc.nextInt();
			int arr[]=new int[n];
			System.out.println("Enter elements to array: ");
			for(int i=0;i<n;i++)
			{
				arr[i]=sc.nextInt();
			}
			System.out.println("trying to accessing out of bound value arr[n+1]");
			int value=arr[n];
			System.out.println(value);
			System.out.println("Elements are");
			for(int i=0;i<n;i++)
			{
				System.out.print(arr[i]+" ");
			}
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("It's out of bound");
			e.printStackTrace();
		}
		
		
	}

}
