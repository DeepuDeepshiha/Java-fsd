package assisted.practice2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Scanner;

public class Project7 {
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a file name with extension:");
		String fname=sc.next();
		System.out.println("----------------------------------");
		File f=new File(fname);
		System.out.println("Select an option,\n 1. Write a file \n 2. Read a file\n 3.Update a file\n 4. Delete a file");
		int opt=sc.nextInt();
		System.out.println("----------------------------------");
		switch(opt)
		{
		case 1:
		{
			System.out.println("Enter a text: ");
			String str=sc.next();
			writefile(f,str);
			System.out.println("File created and wrote successfully");
			System.out.println("----------------------------------");
			break;
		}
		case 2:
		{
			readfile(f);
			break;
		}
		case 3:
		{
			System.out.println("Enter a text you want to update: ");
			String str="\n"+sc.next()+"\n";
			writefile(f,str);
			System.out.println("File updated successfully");
			System.out.println("----------------------------------");
			break;
		}
		case 4:
		{
			deletefile(f);
			System.out.println("----------------------------------");
			break;
		}
		}
	}
	public static void writefile(File f,String s)
	{
		try
		{
			FileWriter fw=new FileWriter(f,true);
			BufferedWriter bw=new BufferedWriter(fw);
			bw.write(s);
			bw.flush();
			bw.close();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}
	public static void readfile(File f)
	{
		try
		{
			FileReader fb=new FileReader(f);
			BufferedReader br=new BufferedReader(fb);
			String line=br.readLine();
			while(line!=null)
			{
				System.out.println(line);
				line=br.readLine();
			}
			br.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void deletefile(File f)
	{
		try
		{
			f.delete();
			System.out.println("File is Deleted");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

}
