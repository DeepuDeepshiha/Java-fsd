package assisted.practice2;
public class Project9 {
	public static void main(String[] args)
	{
		wild w=new wild();
		w.fly();
		w.jump();
	}
}

interface Animal
{
	public static final String name = "Lion";
	void jump();
	
}

interface Bird
{
	public static final String type="Parrot";
	void fly();
}

class wild implements Animal,Bird
{

	@Override
	public void fly() 
	{
		System.out.println("--------------------------");
		System.out.println("Method from Bird Class");
		System.out.println(Bird.type+" is Flying");
		System.out.println("--------------------------");
		
	}

	@Override
	public void jump() 
	{
		System.out.println("--------------------------");
		System.out.println("Method from Animal Class");
		System.out.println(Animal.name+" is jumping");
		System.out.println("--------------------------");
		
	}
	
}