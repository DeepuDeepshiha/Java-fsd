package assisted.practice2;

public class Project2 {
	public static void main(String[] args)
	{
		reverse r=new reverse();
		new Thread() 
		{ 
            @Override 
            public void run() 
            { 
            	r.reverse(10); 
            } 
        }.start();
        
        new Thread() 
        { 
            @Override 
            public void run() 
            { 
            	r.reversenotify();
            } 
        }.start(); 
	}

}

class reverse
{
	
	synchronized public void reverse(int n)
	{
		System.out.println("Printing reverse: ");
		for(int i=n;i>=0;i--)
		{
			System.out.println(i);
			if(i==0)
			{
				try
				{
					wait();
				}
				catch(InterruptedException e)
				{
					e.printStackTrace();
				}
			}
		}
	}
	
	synchronized public void reversenotify()
	{
		notify();
	}

}
