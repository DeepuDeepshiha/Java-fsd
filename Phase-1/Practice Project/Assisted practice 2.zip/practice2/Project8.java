package assisted.practice2;

public class Project8 {

	public static void main(String[] args)
	{
		System.out.println("*****************************************************************");
		System.out.println("Example of Encapsulation, Inheritance and Polymorphism as follows");
		System.out.println("*****************************************************************");
		mother m=new mother();
		m.saree("Cotton saree");
		System.out.println("Object of mother is created as m");
		System.out.println("---------------------------------");
		daughter d=new daughter();
		d.saree();
		System.out.println("---------------------------------");
		System.out.println("Object of daughter is created as d");
		System.out.println("*****************************************************************");
		System.out.println("Example of Data Abstraction as follows");
		System.out.println("*****************************************************************");
		extendabsclass e=new extendabsclass();
		e.show();
	}

}
class mother
{
	String typeofsaree;
	public void saree(String str)
	{
		this.typeofsaree=str;
		System.out.println("It is a method from Class mother");
		System.out.println("---------------------------------");
		System.out.println("Mother says, I prefer to wear "+typeofsaree);
		System.out.println("---------------------------------");
	}
}

class daughter extends mother
{
	public void saree()
	{
		System.out.println("It is a method from Class daughter");
		System.out.println("---------------------------------");
		System.out.println("Daughter says, I will alter your saree to a frock");
	}
}

abstract class absclass
{
	abstract void show();
}

class extendabsclass extends absclass
{

	@Override
	void show() 
	{
		System.out.println("It is an example of Abstract class with abstract method");
		
	}
	
}