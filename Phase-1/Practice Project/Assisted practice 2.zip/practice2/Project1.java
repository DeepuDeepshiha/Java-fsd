package assisted.practice2;

public class Project1 {
	public static void main(String[] args)
	{
		threadclass t=new threadclass();
		t.start();
		threadbyrun tr=new threadbyrun();
		Thread td=new Thread(tr);
		td.start();
	}

}

class threadclass extends Thread
{
	public void run()
	{
		System.out.println("Thread run method by extending Thread class");
		System.out.println("-----------------------------------------------------");
	}
}

class threadbyrun implements Runnable
{

	@Override
	public void run() 
	{
		System.out.println("Thread run method by implementing Runnable Interface");
	}
	
}
