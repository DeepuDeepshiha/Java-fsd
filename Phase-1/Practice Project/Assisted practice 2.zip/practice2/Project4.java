package assisted.practice2;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Project4 {
	public static void main(String[] args)
	{
		try
		{
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter two numbers: ");
			int a=sc.nextInt();
			int b=sc.nextInt();
			int r=a/b;
			System.out.println("Division of two numbers: "+r);
		}
		catch(ArithmeticException e)
		{
			System.out.println("Dividing by zero is not possible ");
			e.printStackTrace();;
		}
		catch(InputMismatchException e)
		{
			System.out.println("Only Integers are allowed as Input");
			e.printStackTrace();
		}
	}

}
