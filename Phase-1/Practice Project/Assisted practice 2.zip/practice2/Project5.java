package assisted.practice2;

public class Project5
{
	public static void main(String[] args)
	{
		int count=0;
		try
		{
			Bank b1=new Bank(1234567,"Rohit",45000);
			b1.deposit(500);
			b1.display();
		}
		catch(depositexception e)
		{
			count++;
			e.printStackTrace();
		}
		finally
		{
			if(count==0)
			{
				System.out.println("Successfully Deposited");
			}
			
		}
	}

}

class Bank
{
	int accno;
	String custname;
	double balance;
	public Bank(int accno, String custname, double balance) 
	{
		super();
		this.accno = accno;
		this.custname = custname;
		this.balance = balance;
	}
	public void deposit(float amt) throws depositexception
	{
		if(amt>1000)
		{
			balance=balance+amt;
		}
		else
		{
			throw new depositexception();
		}
	}
	public void display()
	{
		System.out.println("----------------------------------------------------------");
		System.out.println("Account Holder: "+custname+" Available balance: "+balance);
		System.out.println("----------------------------------------------------------");
	}
	
}

class depositexception extends Exception 
{
	public depositexception()
	{
		System.out.println("Insufficient amount to Deposit");
	}

}