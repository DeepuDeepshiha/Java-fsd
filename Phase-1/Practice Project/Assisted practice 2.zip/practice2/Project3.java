package assisted.practice2;

public class Project3 {
	public static void main(String[] args)
	{
		reversenum r=new reversenum();
		thread1 t1=new thread1(r);
		thread2 t2=new thread2(r);
		t1.start();
		t2.start();
	}

}

class reversenum
{
	synchronized void reverse(int n)
	{
		System.out.println("Printing reverse: ");
		for(int i=n;i>=0;i--)
		{
			System.out.println(i);
			try
			{
				Thread.sleep(1000);
			}
			catch(InterruptedException e)
			{
				e.printStackTrace();
			}
		}
	}
}

class thread1 extends Thread
{
	reversenum r;
	thread1(reversenum  num)
	{
		r=num;
	}
	public void run()
	{
		r.reverse(10);
	}
}

class thread2 extends Thread
{
	reversenum r;
	thread2(reversenum  num)
	{
		r=num;
	}
	public void run()
	{
		r.reverse(5);
	}
}