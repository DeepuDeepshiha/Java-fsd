package assisted.practice4;

import java.util.Scanner;

public class Project7 
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter how many element you want in an array: ");
		int n=sc.nextInt();
		int arr[]=new int[n];
		System.out.println("Enter elements: ");
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		mergesort(arr);
		System.out.println("Sorted array: ");
		for(int i:arr)
		{
			System.out.print(i+" ");
		}
		
	}
	
	public static void mergesort(int a[])
	{
		if(a.length<2)
		{
			return;
		}
		int mid=a.length/2;
		int l[]=new int[mid];
		int r[]=new int[a.length-mid];
		for(int i=0;i<mid;i++)
		{
			l[i]=a[i];
		}
		for(int i=mid;i<a.length;i++)
		{
			r[i-mid]=a[i];
		}
		mergesort(l);
		mergesort(r);
		merge(l,r,a);
	}
	
	public static void merge(int l[],int r[], int a[])
	{
		int lftlen=l.length;
		int rgtlen=r.length;
		int i=0,j=0,k=0;
		while(i<lftlen && j<rgtlen)
		{
			if(l[i]<=r[j])
			{
				a[k++]=l[i++];
			}
			else
			{
				a[k++]=r[j++];
			}
		}
		
		while(i<lftlen)
		{
			a[k++]=l[i++];
		}
		while(j<rgtlen)
		{
			a[k++]=r[j++];
		}
		
	}

}

