package assisted.practice4;

import java.util.Scanner;

public class Project8 
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter how many element you want in an array: ");
		int n=sc.nextInt();
		int arr[]=new int[n];
		System.out.println("Enter elements: ");
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		quicksort(arr,0,n-1);
		System.out.println("Sorted array: ");
		for(int i:arr)
		{
			System.out.print(i+" ");
		}
	}
	
	public static void quicksort(int a[],int l, int h)
	{
		if(l<h)
		{
			int p=partition(a,l,h);
			quicksort(a,l,p-1);
			quicksort(a,p+1,h);
			
		}
	}
	
	public static int partition(int a[],int l,int h)
	{
		int pivot=a[h];
		int i=l-1;
		for(int j=l;j<h;j++)
		{
			if(a[j]<pivot)
			{
				i++;
				int temp=a[i];
				a[i]=a[j];
				a[j]=temp;
			}
		}
		int temp=a[i+1];
		a[i+1]=a[h];
		a[h]=temp;
		
		return i+1;
	}

}