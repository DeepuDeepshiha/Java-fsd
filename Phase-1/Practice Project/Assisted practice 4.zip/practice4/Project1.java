package assisted.practice4;

import java.util.Scanner;

public class Project1 
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter how many element you want in an array: ");
		int n=sc.nextInt();
		int arr[]=new int[n];
		System.out.println("Enter elements: ");
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		System.out.println("Enter element to search: ");
		int k=sc.nextInt();
		linearsearch(arr,k);
	}
	
	public static void linearsearch(int a[],int k)
	{
		boolean flag=false;
		for(int i=0;i<a.length;i++)
		{
			if(a[i]==k)
			{
				flag=true;
				System.out.println("Element found at "+i);
				break;
			}
		}
		if(flag==false)
		{
			System.out.println("Element not found");
		}
		
	}
}
