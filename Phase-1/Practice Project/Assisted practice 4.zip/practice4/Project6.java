package assisted.practice4;

import java.util.Scanner;

public class Project6 
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter how many element you want in an array: ");
		int n=sc.nextInt();
		int arr[]=new int[n];
		System.out.println("Enter elements: ");
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		insertionsort(arr);
		System.out.println("Sorted array: ");
		for(int i:arr)
		{
			System.out.print(i+" ");
		}
		
	}
	
	public static void insertionsort(int a[])
	{
		for(int i=1;i<a.length;i++)
		{
			int key=a[i];
			int j=i-1;
			while(j>=0 && a[j]>key)
			{
				a[j+1]=a[j];
				j=j-1;
			}
			a[j+1]=key;
		}
	}

}