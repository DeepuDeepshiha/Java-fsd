package assisted.practice4;

import java.util.Scanner;

public class Project5 
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter how many element you want in an array: ");
		int n=sc.nextInt();
		int arr[]=new int[n];
		System.out.println("Enter elements: ");
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		bubblesort(arr);
		System.out.println("Sorted array: ");
		for(int i:arr)
		{
			System.out.print(i+" ");
		}
	}
	
	public static void bubblesort(int a[])
	{
		for(int i=0;i<a.length-1;i++)
		{
			for(int j=0;j<a.length-i-1;j++)
			{
				if(a[j]>a[j+1])
				{
					int temp=a[j];
					a[j]=a[j+1];
					a[j+1]=temp;
				}
			}
		}
	}

}