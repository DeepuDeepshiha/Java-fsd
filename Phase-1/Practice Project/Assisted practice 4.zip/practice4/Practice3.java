package assisted.practice4;

import java.util.Scanner;

public class Practice3 
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter how many element you want in an array: ");
		int n=sc.nextInt();
		int arr[]=new int[n];
		System.out.println("Enter elements: ");
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		System.out.println("Enter element to search: ");
		int k=sc.nextInt();
		int res=exponentailsearch(arr,k);
		if(res!=-1)
		{
			System.out.println("Element found at "+res);
		}
		else
		{
			System.out.println("Element not found");
		}
		
	}
	
	public static int exponentailsearch(int a[],int k)
	{
		if(a[0]==k)
		{
			System.out.println("Element found at 0");
		}
		int i=1;
		while(i<a.length && a[i]<=k)
		{
			i=i*2;
		}
		return binarysearch(a, k, i / 2, Math.min(i, a.length - 1));
	}
	
	public static int binarysearch(int a[],int k,int l,int r)
	{
		if(r>=l)
		{
			int mid=l+(r-l)/2;
			if(a[mid]==k)
			{
				return mid;
			}
			else if(a[mid]<k)
			{
				return binarysearch(a,k,mid+1,r);
			}
			else
			{
				return binarysearch(a,k,l,mid-1);
			}
		}
		return -1;
	}
}
