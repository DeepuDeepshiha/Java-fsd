package assisted.practice4;

import java.util.Scanner;

public class Project2 
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter how many element you want in an array: ");
		int n=sc.nextInt();
		int arr[]=new int[n];
		System.out.println("Enter elements: ");
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		System.out.println("Enter element to search: ");
		int k=sc.nextInt();
		binarysearch(arr,k);
	}
	
	public static void binarysearch(int a[],int k)
	{
		
		int l=0;
		int r=a.length-1;
		while(l<=r)
		{
			int mid=(l+r)/2;
			if(a[mid]==k)
			{
				System.out.println("Element found at "+mid);
				break;
			}
			else if(a[mid]<k)
			{
				l=mid+1;
			}
			else
			{
				r=mid-1;
			}
			mid=(l+r)/2;
		}
		if(l>r)
		{
			System.out.println("Element not found");
		}
	}
}
