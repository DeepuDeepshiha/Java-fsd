package assisted.pratice3;

import java.util.Arrays;
import java.util.Scanner;

public class Project1 {
	public static void main(String[] args)
	{
		
		System.out.println("Enter an no, of element you want to enter: ");
		Scanner sc=new Scanner(System.in);
		int arrlen=sc.nextInt();
		int arr[] = new int[arrlen];
		System.out.println("Enter elements: ");
		for(int i=0;i<arrlen;i++)
		{
			arr[i]=sc.nextInt();
		}
		rotation(arr,5);
		System.out.println("After right rotation by 5 steps: ");
		System.out.println(Arrays.toString(arr));
		
	}
	
	public static void rotation(int arr[],int n)
	{
		int len=arr.length;
		n=n%len;
		reverse(arr,0,len-1);
		reverse(arr,0,n-1);
		reverse(arr,n,len-1);
	}
	
	public static void reverse(int arr[],int start,int end)
	{
		while(start<end)
		{
			int temp=arr[start];
			arr[start]=arr[end];
			arr[end]=temp;
			start++;
			end--;
		}
	}

}

