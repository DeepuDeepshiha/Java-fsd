package assisted.pratice3;
class queue
{
	int front=-1;
	int rear=-1;
	int arr[];
	int n;
	
	public queue(int n)
	{
		this.n=n;
		arr=new int[n];
	}
	
	public boolean isFull()
	{
		return rear==n-1;
	}
	
	public boolean isEmpty()
	{
		return front==-1 && rear==-1;
	}
	
	public void enqueue(int data)
	{
		if(isFull())
		{
			System.out.println("Queue is full");
		}
		else if(isEmpty())
		{
			rear=front=0;
			arr[rear]=data;
		}
		else
		{
			rear++;
			arr[rear]=data;
		}
	}
	
	public int dequeue()
	{
		if(isEmpty())
		{
			System.out.println("Queue is empty");
		}
		else if(front==rear)
		{
			int value=arr[front];
			front=rear=-1;
			return value;
		}
		else
		{
			int value=arr[front];
			front++;
			return value;
		}
		return 0;
	}
}
public class Project9 {
	public static void main(String[] args)
	{
		queue q=new queue(4);
		q.enqueue(10);
		q.enqueue(55);
		q.enqueue(65);
		q.enqueue(14);
		System.out.println("Removing elements from queue: ");
		for(int i=0;i<4;i++)
		{
			System.out.print(q.dequeue()+" ");
			
		}
	}

}
