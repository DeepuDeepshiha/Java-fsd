package assisted.pratice3;

import java.util.Arrays;
import java.util.Scanner;

public class Project2 {
	public static void main(String[] args)
	{
		System.out.println("Enter an no, of element you want to enter: ");
		Scanner sc=new Scanner(System.in);
		int arrlen=sc.nextInt();
		int arr[] = new int[arrlen];
		System.out.println("Enter elements: ");
		for(int i=0;i<arrlen;i++)
		{
			arr[i]=sc.nextInt();
		}
		System.out.println("Fourth  smallest number is "+findfourthsmall(arr));
		
	}
	public static int findfourthsmall(int arr[])
	{
		if(arr.length<4)
		{
			System.out.println("Length should be atleast 4");
			return -1;
		}
		else
		{
			Arrays.sort(arr);
			return arr[3];
		}
	}

}
