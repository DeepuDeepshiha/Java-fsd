package assisted.pratice3;
import java.util.Scanner;
public class Project4 {
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter how many rows and column you want in matrix1: ");
		int r1=sc.nextInt();
		int c1=sc.nextInt();
		int arr1[][]=new int[r1][c1];
		System.out.println("Enter elemetns in matrix1: ");
		for(int i=0;i<r1;i++)
		{
			for(int j=0;j<c1;j++)
			{
				arr1[i][j]=sc.nextInt();
			}
		}
		System.out.println("Enter how many rows and column you want in matrix2: ");
		int r2=sc.nextInt();
		int c2=sc.nextInt();
		int arr2[][]=new int[r1][c1];
		System.out.println("Enter elements in matrix2: ");
		for(int i=0;i<r2;i++)
		{
			for(int j=0;j<c2;j++)
			{
				arr2[i][j]=sc.nextInt();
			}
		}
		matrixmultiply(arr1,arr2,r1,r2,c1,c2);
	}
	
	public static void matrixmultiply(int a[][],int b[][],int r1,int r2,int c1,int c2)
	{
		if(r2!=c1)
		{
			System.out.println("Multiplication is not possible");
		}
		else
		{
			int res[][]=new int[r1][c2];
			for(int i=0;i<r1;i++)
			{
				for(int j=0;j<c2;j++)
				{
					for(int k=0;k<r2;k++)
					{
						res[i][j]=res[i][j]+(a[i][k]*b[k][j]);
					}
				}
			}
			System.out.println("Matrix 1: ");
			for(int i=0;i<r1;i++)
			{
				for(int j=0;j<c1;j++)
				{
					System.out.print(a[i][j]+" ");
				}
				System.out.println();
			}
			System.out.println();
			System.out.println("Matrix 2: ");
			for(int i=0;i<r2;i++)
			{
				for(int j=0;j<c2;j++)
				{
					System.out.print(b[i][j]+" ");
				}
				System.out.println();
			}
			System.out.println();
			System.out.println("After multiplication2 matrix");
			for(int i=0;i<r1;i++)
			{
				for(int j=0;j<c2;j++)
				{
					System.out.print(res[i][j]+" ");
				}
				System.out.println();
			}
			
		}
		
	}

}
