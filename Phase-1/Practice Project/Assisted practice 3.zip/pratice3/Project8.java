package assisted.pratice3;
class stack
{
	int n;
	int arr[];
	int top;
	public stack(int n)
	{
		this.n=n;
		this.arr=new int[n];
		this.top=-1;
	}
	public void push(int data)
	{
		if(isFull())
		{
			System.out.println("Stack is full");
			
		}
		else
		{
			top++;
			arr[top]=data;
		}
	}
	
	public int pop()
	{
		if(isEmpty())
		{
			System.out.println("Stack is empty");
		}
		else
		{
			int value=arr[top];
			top--;
			return value;
		}
		return 0;
	}
	
	public boolean isFull()
	{
		return n-1 ==top;
	}
	
	public boolean isEmpty()
	{
		return top==-1;
	}
}
public class Project8
{
	public static void main(String[] args)
	{
		stack s=new stack(5);
		s.push(10);
		s.push(55);
		s.push(66);
		s.push(34);
		s.push(15);
		System.out.println("Removing elements from stack:");
		for(int i=0;i<5;i++)
		{
			System.out.print(s.pop()+" ");
		}
	}

}
