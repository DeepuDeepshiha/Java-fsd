package assisted.pratice3;
class node
{
	int value;
	node next;
	node(int value)
	{
		this.value=value;
		next=null;
	}
}

class linkedlist
{
	node head;
	public linkedlist()
	{
		head=null;
	}
	
	public void push(int data)
	{
		node newnode=new node(data);
		if(head==null)
		{
			head=newnode;
		}
		else
		{
			node temp=head;
			while(temp.next!=null)
			{
				temp=temp.next;
			}
			temp.next=newnode;
		}
	    
	}
	
	public int pop()
	{
		if(isEmpty())
		{
			System.out.println("Linkedlist is empty");
			return 0;
		}
		else
		{
			int data=head.value;
			head=head.next;
			return data;
		}
	}
	
	public boolean isEmpty()
	{
		return head==null;
	}
	
	public void deletenode(int key)
	{
		node temp=head;
		if(head==null)
		{
			System.out.println("Linkedlist empty");
		}
		if(head.value==key)
		{
			head=head.next;
		}
		while(temp.next!=null)
		{
			System.out.print(temp.value + " ");
            temp = temp.next;
		}
	}
	
	public void printList() 
	{
        node temp = head;
        while (temp != null) 
        {
            System.out.print(temp.value + " ");
            temp = temp.next;
        }
        System.out.println();
    }
}
public class Project5 {
	
	public static void main(String[] args)
	{
		linkedlist l=new linkedlist();
		l.push(11);
		l.push(12);
		l.push(13);
		l.push(14);
		l.push(12);
		l.push(12);
		System.out.println("Linked list: ");
		l.printList();
		System.out.println("Linked listafter deleting 1st occurence of 12: ");
		l.deletenode(12);
		System.out.println();
		
		
		
	}

}
