package assisted.pratice3;

import java.util.Scanner;

public class Project3 {
	public static void main(String[] args)
	{
		System.out.println("Enter an no, of element you want to enter: ");
		Scanner sc=new Scanner(System.in);
		int arrlen=sc.nextInt();
		int arr[] = new int[arrlen];
		System.out.println("Enter elements: ");
		for(int i=0;i<arrlen;i++)
		{
			arr[i]=sc.nextInt();
		}
		System.out.println("Enter 2 index numbers to get sum of each element between them");
		int l=sc.nextInt();
		int r=sc.nextInt();
		int sum=0;
		if(l<r && l<arrlen && r<arrlen)
		{
			for(int i=l;i<=r;i++)
			{
				sum=sum+arr[i];
			}
			System.out.print("Sum of elements between l and r is "+sum);
		}
		else
		{
			System.out.print("Not possible");
		}
	}

}
