package assisted.pratice3;
class nodes
{
	int data;
	nodes next;
	public nodes(int data)
	{
		this.data=data;
		this.next=null;
	}
}

class CircularLinkedList 
{
    nodes head;

    void insert(int newData) 
    {
        nodes newNode = new nodes(newData);
        nodes current = head;
        if (head == null) 
        {
            newNode.next = newNode;
            head = newNode;
        }
        
        else if (newData <= head.data)
        { 
            newNode.next = head;
            nodes last = getLastNode();
            last.next = newNode;
            head = newNode;
        } 
        
        else 
        {
            while (current.next != head && current.next.data < newData) {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }
    }
    
    
    nodes getLastNode()
    {
        nodes temp = head;
        while (temp.next != head) 
        {
            temp = temp.next;
        }
        return temp;
    }

    void display() {
        nodes temp = head;
        if (head != null) {
            do {
                System.out.print(temp.data + " ");
                temp = temp.next;
            } while (temp != head);
            System.out.println();
        }
    }
}
public class Project7 {
	public static void main(String[] args)
	{
		CircularLinkedList lst = new CircularLinkedList();
        lst.insert(1);
        lst.insert(2);
        lst.insert(4);
        lst.insert(3);
        System.out.println("Sorted Circular Linked List:");
        lst.display();
	}

}
