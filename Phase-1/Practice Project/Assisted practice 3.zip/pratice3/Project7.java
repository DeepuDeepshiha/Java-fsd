package assisted.pratice3;
class Node1 {
    int data;
    Node1 prev;
    Node1 next;

    Node1(int d) {
        data = d;
        prev = null;
        next = null;
    }
}

class DoublyLinkedList {
    Node1 head;

    DoublyLinkedList() 
    {
        head = null;
    }
    void insertAtEnd(int data)
    {
        Node1 newNode = new Node1(data);

        if (head == null) {
            head = newNode;
            return;
        }

        Node1 current = head;
        while (current.next != null) 
        {
            current = current.next;
        }

        current.next = newNode;
        newNode.prev = current;
    }
    
    void traverseForward() 
    {
        if (head == null)
        {
            System.out.println("List is empty");
            return;
        }

        System.out.print("Forward traversal: ");
        Node1 current = head;
        while (current != null)
        {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    void traverseBackward()
    {
        if (head == null) 
        {
            System.out.println("List is empty");
            return;
        }

        System.out.print("Backward traversal: ");
        Node1 current = null;
        for (current = head; current.next != null; current = current.next);

        while (current != null) 
        {
            System.out.print(current.data + " ");
            current = current.prev;
        }
        System.out.println();
    }
}

public class Project7 
{
	public static void main(String[] args)
	{
		DoublyLinkedList list = new DoublyLinkedList();

        list.insertAtEnd(5);
        list.insertAtEnd(10);
        list.insertAtEnd(15);
        list.insertAtEnd(20);
        list.insertAtEnd(25);

        list.traverseForward();
        list.traverseBackward();
	}

}
